#!/usr/bin/env bash
# SaaS Creator OS — scaffold a new project's state/ from the templates.
# Usage:  bash init-project.sh [project-name]
set -euo pipefail

# Resolve the OS root (this script lives in <os-root>/scripts/)
OS_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NAME="${1:-my-product}"

if [ -d "./state" ]; then
  echo "state/ already exists here — refusing to overwrite. Delete it first if you really mean to."
  exit 1
fi

mkdir -p ./state/features ./prompts
cp "$OS_ROOT/templates/state/project.yaml"  ./state/project.yaml
cp "$OS_ROOT/templates/state/backlog.yaml"  ./state/backlog.yaml
cp "$OS_ROOT/templates/state/progress.json" ./state/progress.json
cp "$OS_ROOT/templates/state/features/_feature.template.yaml" ./state/features/_feature.template.yaml

# Seed the project name (portable in-place sed for macOS + Linux)
if sed --version >/dev/null 2>&1; then
  sed -i    "s/<project-name>/$NAME/" ./state/project.yaml
else
  sed -i '' "s/<project-name>/$NAME/" ./state/project.yaml
fi

# Drop the project kernel if none exists
if [ ! -f ./CLAUDE.md ]; then
  cp "$OS_ROOT/templates/project.CLAUDE.md" ./CLAUDE.md
  echo "Wrote ./CLAUDE.md (project kernel). Fill in the overrides."
fi

echo "Scaffolded state/ for '$NAME'."
echo "Next:  open Claude Code here and run   /discover \"<your idea>\""
