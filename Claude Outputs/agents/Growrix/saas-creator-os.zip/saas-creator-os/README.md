# SaaS Creator OS

**An AI development operating system built *inside* Claude Code.** It turns a one-line idea into a
shipped product by enforcing a lifecycle, generating the plan and prompt packs, and refusing to let a
feature be "done" until its Definition of Done is actually met. It exists to cure one specific pain:
*"I get confused what to do next, so my project never ends."*

> **Core principle:** this is **not** a web app you build and maintain. Claude Code already has the
> parts to *be* this OS — you configure it. The optional HTML dashboard (`dashboard/index.html`) is
> just a read-out of the state files, not the engine.

---

## What's in the box

```
saas-creator-os/
├─ .claude-plugin/plugin.json   ← plugin manifest
├─ CLAUDE.md                    ← the kernel (operating laws) — copy into each project
├─ settings.json                ← hook registration for MANUAL install (plugin users can ignore)
├─ agents/                      ← 8 specialist subagents (discovery, prd, architect, blueprint,
│                                  prompt-factory, validator, planner, knowledge)
├─ skills/                      ← 11 phase skills (/discover … /ship) + 7 on-demand Bibles
│  └─ bibles/                     (auth, database, stripe, nextjs, supabase, testing, devops)
├─ hooks/                       ← resume · inject-phase · check · dod-gate  (+ hooks.json)
├─ blueprints/                  ← 6 project-type workflows (marketing, saas, ai-saas, ecommerce,
│                                  marketplace, mobile)
├─ templates/                   ← state-file + prompt-pack + project-kernel templates
├─ scripts/init-project.sh      ← scaffold a new project's state/
├─ libraries/                   ← reusable assets harvested from finished projects (grows over time)
├─ examples/dse-halal-tracker/  ← a pre-filled real project (also powers the dashboard demo)
└─ dashboard/index.html         ← the single-file "command center" cockpit (Stage 6)
```

---

## The lifecycle

```
Discover → Plan → Specify → Architect → Bluebook → Prompt Packs →
Execute → Validate → Test → Deploy → Launch → Operate → Improve
```

Each phase has prerequisites (can't start until the prior is approved) and an objective Definition of
Done. You never decide what's next — you run `/next` and the state files answer.

---

## Install

### Option A — as a Claude Code plugin (recommended, reusable everywhere)
1. Put this folder in a git repo (or a plugin marketplace).
2. In Claude Code: `/plugin` → add the marketplace/repo → install **saas-creator-os**.
3. The subagents, skills, and hooks load automatically (hooks come from `hooks/hooks.json`).

### Option B — manual, into a single project
1. Copy this folder to `<your-project>/.claude/saas-creator-os/`.
2. Copy `agents/` and `skills/` into `<your-project>/.claude/` (Claude Code reads `.claude/agents`
   and `.claude/skills`).
3. Merge `settings.json`'s `hooks` block into `<your-project>/.claude/settings.json` (fix the paths).
4. Copy `CLAUDE.md` to the project root.

---

## Quickstart (60 seconds)

```bash
# in a fresh project folder, with the OS installed:
bash <os>/scripts/init-project.sh my-product      # scaffolds state/ and CLAUDE.md
# then, inside Claude Code:
/discover "a booking tool for home tutors"        # CTO-style discovery → state/project.yaml
/plan                                             # PRD + backlog
/architect                                        # folders, schema, API, deployment
/blueprint authentication                         # spec + DoD + prompt pack for one feature
/next                                             # → the one exact next task
/execute authentication                           # build it (plan first, then code, build stays green)
/validate authentication                          # PASS/FAIL against the DoD (read-only)
/approve authentication                           # record sign-off → /next unlocks the next feature
/status                                           # progress, % complete, deadline risk
/ship                                             # launch checklist (only when MVP features are done)
```

Open the project and the **SessionStart** hook prints *"you are here"* — you resume in seconds.

---

## The four hooks (why it's an engine, not a doc)

| Hook (event) | Does | Kills |
|---|---|---|
| `resume.sh` (SessionStart) | Prints current phase / feature / next task | Re-orienting from scratch every session |
| `inject-phase.sh` (UserPromptSubmit) | Reminds the model of phase + next task each turn | The AI drifting off-plan |
| `check.sh` (PostToolUse) | Typecheck + lint after edits (warn by default; `SCOS_STRICT=1` to block) | Silent broken code |
| `dod-gate.sh` (Stop) | **Blocks (exit 2)** any feature left `done` with unmet DoD or no approval | "Fake done" — completion must be earned |

The DoD gate is deliberately narrow: it only fires on a genuine fake-done inconsistency, so normal
turns end freely.

---

## Your job (only four things)
1. **Answer business questions** during `/discover`.
2. **Review output** (plan mode shows the plan before code runs).
3. **Approve or reject** with `/approve` (the only path to "done").
4. **Trigger deploy/launch** with `/ship`.

Everything else is generated. The system never asks *"what do you want to build next?"* — it says
*"here is the next approved task."*

---

## Build the OS itself in stages (don't over-build the meta-tool)
- **Stage 1 (ship first):** `/discover`, `/plan`, `/next`, `/status` + `resume.sh` → you can never be lost again.
- **Stage 2:** `architect`, `blueprint`, `prompt-factory` → idea to prompt packs.
- **Stage 3:** `validator` + `dod-gate` + `check` → "no fake done", enforced.
- **Stage 4:** the Bibles → consistent expertise, grown over time.
- **Stage 5:** blueprints + libraries → package as a plugin, reuse everywhere.
- **Stage 6:** `dashboard/index.html` → the visual cockpit (already included here).

## Dogfood it
Point it at a real project (the included `examples/dse-halal-tracker/` is exactly that). Building a real
product is how you battle-test the OS.

---

Built by **GrowrixOS** · https://growrixos.com · MIT
