#!/usr/bin/env bash
# SaaS Creator OS — Stop hook. The "no fake done" gate.
# Blocks (exit 2) if any feature is marked status:done while a DoD item is false or approval is missing.
# Only fires on a genuine inconsistency, so normal turn-ends are never affected.
set -uo pipefail
DIR="./state/features"
[ -d "$DIR" ] || exit 0
VIOLATION=""
for f in "$DIR"/*.yaml; do
  [ -e "$f" ] || continue
  STATUS="$(grep -m1 '^[[:space:]]*status:' "$f" 2>/dev/null | sed -E 's/.*status:[[:space:]]*//; s/[" ]//g')"
  if [ "$STATUS" = "done" ]; then
    APPROVED="$(grep -m1 '^[[:space:]]*approved_by_human:' "$f" 2>/dev/null | sed -E 's/.*approved_by_human:[[:space:]]*//; s/[" ]//g')"
    UNMET="$(grep -c 'done:[[:space:]]*false' "$f" 2>/dev/null)"; UNMET="${UNMET//[^0-9]/}"; UNMET="${UNMET:-0}"
    if [ "$UNMET" -gt 0 ] || [ "$APPROVED" != "true" ]; then
      VIOLATION="${VIOLATION}
  - $(basename "$f"): status=done but ${UNMET} DoD item(s) unmet / approved_by_human=${APPROVED:-missing}"
    fi
  fi
done
if [ -n "$VIOLATION" ]; then
  printf "SaaS Creator OS — BLOCKED: completion must be earned, not asserted.%s\nFix the DoD (run /validate) and record human sign-off (/approve), or revert the feature status. Do not leave a feature 'done' with unmet DoD.\n" "$VIOLATION" >&2
  exit 2
fi
exit 0
