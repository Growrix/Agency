#!/usr/bin/env bash
# SaaS Creator OS — SessionStart hook.
# Prints "you are here" from state/project.yaml so you resume instantly, never re-orient.
set -uo pipefail
STATE="./state/project.yaml"
if [ ! -f "$STATE" ]; then
  echo "SaaS Creator OS: no state/ in this project yet. Run  /discover \"<idea>\"  to begin (or scripts/init-project.sh to scaffold)."
  exit 0
fi
val() { grep -m1 "^[[:space:]]*$1:" "$STATE" 2>/dev/null | sed -E "s/^[[:space:]]*$1:[[:space:]]*//; s/[\"]//g"; }
PROJECT="$(val project)"; [ -z "$PROJECT" ] && PROJECT="$(val name)"
PHASE="$(val phase)"
FEATURE="$(val current_feature)"
NEXT="$(val next_task)"
echo "================ SaaS Creator OS — you are here ================"
echo "  Project : ${PROJECT:-unnamed}"
echo "  Phase   : ${PHASE:-discover}"
echo "  Feature : ${FEATURE:-—}"
echo "  Next    : ${NEXT:-run /next}"
echo "  Tips    : /status = full progress   /next = the exact next task"
echo "==============================================================="
exit 0
