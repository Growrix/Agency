#!/usr/bin/env bash
# SaaS Creator OS — PostToolUse hook (matcher: Write|Edit|MultiEdit).
# Keeps build awareness after edits. WARN by default (never blocks mid-refactor);
# set SCOS_STRICT=1 to make failures blocking (exit 2). The hard "done" gate is dod-gate.sh.
set -uo pipefail
[ -f package.json ] || exit 0
command -v npx >/dev/null 2>&1 || exit 0
FAIL=0; MSG=""
if grep -q '"typescript"' package.json 2>/dev/null; then
  if ! npx --no-install tsc --noEmit >/tmp/scos_tsc.log 2>&1; then
    FAIL=1; MSG="${MSG}
TypeScript:
$(tail -n 25 /tmp/scos_tsc.log)"
  fi
fi
if grep -q '"lint"' package.json 2>/dev/null; then
  if ! npm run -s lint >/tmp/scos_lint.log 2>&1; then
    FAIL=1; MSG="${MSG}
Lint:
$(tail -n 15 /tmp/scos_lint.log)"
  fi
fi
if [ "$FAIL" -eq 1 ]; then
  printf "SaaS Creator OS check — issues after edit (address before marking DoD):%s\n" "$MSG" >&2
  if [ "${SCOS_STRICT:-0}" = "1" ]; then exit 2; fi
fi
exit 0
