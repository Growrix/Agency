#!/usr/bin/env bash
# SaaS Creator OS — UserPromptSubmit hook.
# Quietly reminds the model of the current phase + next task so it never drifts off-plan.
set -uo pipefail
STATE="./state/project.yaml"
[ -f "$STATE" ] || exit 0
val() { grep -m1 "^[[:space:]]*$1:" "$STATE" 2>/dev/null | sed -E "s/^[[:space:]]*$1:[[:space:]]*//; s/[\"]//g"; }
PHASE="$(val phase)"; NEXT="$(val next_task)"; FEATURE="$(val current_feature)"
[ -z "${PHASE}${NEXT}${FEATURE}" ] && exit 0
echo "[SaaS Creator OS] phase=${PHASE:-?} | active_feature=${FEATURE:-none} | next=${NEXT:-run /next}. Stay on the lifecycle; derive the next action from state/. If unsure, run /next. Do not mark a feature done unless its DoD is 100% and approved."
exit 0
