# DSE Halal Tracker — runs on SaaS Creator OS

Governed by the SaaS Creator OS kernel. Project-specific overrides below.

## Project overrides
- Special constraints: **Shariah compliance is a hard filter.** No conventional-interest instruments;
  purification + zakat required. AI features must not give buy/sell signals or issue fatwas.
- Data: real DSE data only (dsebd.org scraping + bdshare/bd-stock-api). No mock data.
- Deadline: 2026-10-15

Start or resume with /status, then /next.
