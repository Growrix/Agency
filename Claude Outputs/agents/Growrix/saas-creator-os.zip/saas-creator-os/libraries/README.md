# Reusable Asset Library

This folder is where the OS accumulates value across projects. After a feature or project ships, the
**knowledge** subagent harvests anything worth reusing and drops it here so nothing is built twice.

## What goes here
- `components/` — proven, generic UI components (logic + structure, NOT a client's visual identity)
- `patterns/` — reusable architecture patterns (auth flow, RBAC model, webhook handler, importer)
- `prompts/` — prompt packs that worked well, ready to lift into a new project
- `snippets/` — small utilities (money math, date helpers, validation schemas)

## Rules
- Reuse **logic and patterns**, never a specific brand's look, copy, or identity.
- Every asset gets a one-paragraph README: what it is, when to reuse it, what to change.
- Add or refine — never delete. This library only grows.

_Empty to start. It fills itself as you ship._
