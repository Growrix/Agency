---
name: blueprint
description: Create the full build spec and Definition of Done for ONE feature, plus its prompt pack. Use before building any individual feature.
argument-hint: "<feature-id>"
---

# /blueprint

1. Invoke the **blueprint** subagent for feature `$ARGUMENTS`, pulling in the relevant Bible(s).
   It writes `state/features/$ARGUMENTS.yaml` including an objective `dod:` checklist.
2. Invoke the **prompt-factory** to write the copy-paste prompt pack into `prompts/$ARGUMENTS/`.
3. Set the feature `phase: specify`. Tell the human the feature is specced; run `/next` to begin building.

Every DoD item must be objectively checkable.
