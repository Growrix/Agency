---
name: next
description: Tell me the single next approved task based on the blueprint and current state. Use whenever I am unsure what to do next. This is the anti-lost command.
---

# /next

1. Read `state/project.yaml` (current `phase`) and `state/backlog.yaml` (ordered features).
2. Read `state/features/*.yaml` to see what is in progress or blocked.
3. Find the **first** task whose prerequisites are all satisfied/approved.
4. Output **only that one task**:
   - its name and why it is next,
   - what "done" means for it (the specific DoD items),
   - the exact skill to run to do it (e.g. `/blueprint`, `/execute`, `/validate`, `/approve`).

Do not list everything. One next step. If the whole backlog is done, say the project is ready for
`/ship` (or the next phase).
