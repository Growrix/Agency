---
name: execute
description: Build the current step of a feature under the OS guardrails. Use to actually implement code once a feature is specced. Argument is the feature id (and optional step).
argument-hint: "<feature-id> [step]"
---

# /execute

1. Read `state/features/<id>.yaml` and the matching prompt in `prompts/<id>/`.
2. Present the plan first (plan mode) and wait for approval before writing code.
3. Implement the smallest next increment. After each edit, let the `check` hook run typecheck + lint
   and fix any failures before continuing.
4. As DoD items become true, update their `done:` and `evidence:` fields in the feature file.
5. Do **not** mark the feature `status: done` yourself — that is earned via `/validate` then `/approve`.

Stay inside the current feature. If something outside scope is needed, note it in the backlog and
keep going.
