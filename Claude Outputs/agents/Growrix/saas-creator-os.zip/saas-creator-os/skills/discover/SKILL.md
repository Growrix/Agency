---
name: discover
description: Start a new project by turning a one-line idea into a discovery brief. Use at the very beginning, before any planning. Invoke with the idea as the argument.
argument-hint: "<one-line product idea>"
---

# /discover

1. If `state/` does not exist yet, run `scripts/init-project.sh` (or create the state files from
   `templates/`) so there is somewhere to write.
2. Record the raw idea (`$ARGUMENTS`) into `state/project.yaml` under `idea:`.
3. Invoke the **discovery** subagent to run a CTO-style discovery session and fill the
   `discovery:` block plus set `project.type` to the right blueprint.
4. When discovery is complete, set `phase: discover` → mark discovery `approved: false` and tell the
   human to review it, then run `/plan`.

Ask questions one at a time. Do not write code in this phase.
