---
name: ship
description: Run the launch checklist before going to production — security, SEO, performance, accessibility, analytics, monitoring, backups, legal, domain, emails, billing. Use only when the MVP features are all approved.
disable-model-invocation: true
---

# /ship

Prerequisite: every MVP feature in `state/backlog.yaml` is `status: done`.

Walk the launch checklist and check each item against the real project (not from memory):
- **Security:** secrets not committed, RLS/authorization on every table/route, dependency audit.
- **Performance:** Core Web Vitals green, images via next/image, fonts via next/font, bundle sane.
- **Accessibility:** keyboard nav, focus states, contrast AA+, semantic landmarks, alt text.
- **SEO:** metadata, sitemap, robots, Open Graph, canonical URLs.
- **Ops:** analytics, logging, error monitoring, backups, CI/CD, rollback plan.
- **Business/legal:** domain + DNS, transactional email, privacy policy, terms, cookies, support.

Only when every item passes: mark `phase: launch` and tell the human launch is approved. Anything
unmet becomes a blocking task in the backlog. There is no "ship anyway".
