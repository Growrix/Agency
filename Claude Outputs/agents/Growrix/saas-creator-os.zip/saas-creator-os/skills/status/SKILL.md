---
name: status
description: Show project progress — current phase, percent complete, what is in progress, what is blocked, the next task, and whether the deadline is at risk. Use anytime to orient.
---

# /status

1. Invoke the **planner** subagent to recompute `state/progress.json` from the state files.
2. Render a short dashboard: phase · % complete · features done/total · in-progress · blocked ·
   next task · days remaining · on-track (yes/no) · top risk.

Keep it to a screenful. End with the single next action (usually the output of `/next`).
