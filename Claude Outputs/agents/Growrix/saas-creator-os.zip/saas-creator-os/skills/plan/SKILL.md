---
name: plan
description: Generate the PRD and seed the backlog from an approved discovery brief. Use after /discover is reviewed.
---

# /plan

Prerequisite: `state/project.yaml` has an approved `discovery:` block.

1. Invoke the **prd** subagent to write `state/prd.md` and seed an ordered `state/backlog.yaml`.
2. Set `phase: plan`. Tell the human to review the PRD and MVP cut, then run `/architect`.

Every feature in the PRD must carry acceptance criteria. Draw a clear MVP line.
