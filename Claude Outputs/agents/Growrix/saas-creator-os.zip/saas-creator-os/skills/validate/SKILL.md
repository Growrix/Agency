---
name: validate
description: Run the Definition-of-Done validator on a feature and update its state file with PASS or FAIL and evidence. Use after building a feature, before approving it.
argument-hint: "<feature-id>"
---

# /validate

1. Invoke the **validator** subagent on feature `$ARGUMENTS`. It checks every DoD item with
   read-only tools and writes `done:`/`evidence:` back to `state/features/$ARGUMENTS.yaml`.
2. If the verdict is **PASS**, tell me to run `/approve $ARGUMENTS`.
3. If **FAIL**, list the exact failing DoD items and which `/execute` step or prompt fixes each.

The validator never edits code and never marks the feature approved.
