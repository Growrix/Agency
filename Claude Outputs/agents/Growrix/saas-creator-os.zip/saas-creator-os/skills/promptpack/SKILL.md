---
name: promptpack
description: (Re)generate the ordered copy-paste prompt pack for a feature, ready to paste into Cursor / Claude Code / Codex. Use if you want the prompts regenerated or updated.
argument-hint: "<feature-id>"
---

# /promptpack

Invoke the **prompt-factory** subagent for feature `$ARGUMENTS`. It writes numbered prompts
(`01-plan.md` … `07-deploy.md`, only the steps this feature needs) into `prompts/$ARGUMENTS/`,
each self-contained and ending in a "Done when:" line that maps to a DoD item.
