---
name: approve
description: Record the human's sign-off on a feature that has passed validation. This is the only way a feature becomes complete. Use after /validate returns PASS.
argument-hint: "<feature-id>"
---

# /approve

Prerequisite: the validator has marked every DoD item `true` in `state/features/$ARGUMENTS.yaml`.

1. Re-check that all DoD items are `true`. If any is `false`, refuse and point to `/validate`.
2. Set `approved_by_human: true` and `status: done` on the feature.
3. Update `state/progress.json` (via the **planner**) and run `/next` to reveal the next task.

If DoD is not 100%, this command must refuse — completion is earned, not asserted. The `dod-gate`
hook will also block any inconsistent "done".
