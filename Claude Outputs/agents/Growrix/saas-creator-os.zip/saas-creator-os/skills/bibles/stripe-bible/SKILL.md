---
name: stripe-bible
description: Payments and subscriptions standard — products, prices, checkout, customer portal, webhooks, invoices, trials, taxes, and reconciliation. Loads when adding billing, subscriptions, or checkout.
---

# Stripe Bible

## The standard
- Define products/prices in Stripe (or via API), reference price IDs in the app — never hardcode amounts in UI.
- Use **Checkout** for payment collection and the **Customer Portal** for plan changes/cancellation.
- The **webhook is the source of truth** for subscription state. Do not grant access on the redirect
  success page alone — wait for `checkout.session.completed` / `customer.subscription.updated`.
- Store the Stripe `customer` id and subscription status in your DB; keep them in sync via webhooks.

## Checklist
- [ ] Products/prices created; price IDs referenced (not hardcoded amounts)
- [ ] Checkout + Portal wired; success/cancel URLs correct
- [ ] Webhook endpoint verifies the signature; handles completed, updated, deleted, payment_failed
- [ ] Subscription status persisted in DB and used to gate features server-side
- [ ] Trials, proration, and taxes configured as required; test-mode + live-mode keys separated
- [ ] Idempotent webhook handling (safe to receive the same event twice)

## Common mistakes (avoid)
- Granting access on the client redirect before the webhook confirms payment.
- Not verifying the webhook signature (spoofable). Non-idempotent handlers double-applying events.
- Hardcoding prices in the UI so a Stripe change and the app drift apart.

## How the best do it
Webhook-driven state, idempotency keys, entitlements gated server-side, reconciliation jobs. Treat the
redirect as UX only; treat the webhook as truth.

## Prompt pack
Products/prices → checkout session → portal → webhook (signed, idempotent) → DB sync → entitlement gate → tests.
