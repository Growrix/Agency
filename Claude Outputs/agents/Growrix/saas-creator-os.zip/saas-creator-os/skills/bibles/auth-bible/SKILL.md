---
name: auth-bible
description: Authentication and authorization standard — email/OAuth/magic-link/OTP login, sessions, route protection, roles/RBAC, and the common mistakes. Loads when building sign-in, sign-up, permissions, or middleware.
---

# Authentication Bible

## The standard (default: Clerk + Next.js App Router)
- Sessions handled by the auth provider; never roll your own password hashing or JWT unless required.
- Protect routes in **middleware**, not per-page. Server Components read the session server-side.
- Model **authorization** (what a user may do) separately from **authentication** (who they are).
  Roles/permissions live in the database and are enforced on the server and in RLS — never trusted
  from the client.

## Checklist
- [ ] Providers wired (email + at least one OAuth) with correct callback/redirect URLs (localhost + prod)
- [ ] Middleware protects private routes; public routes explicitly allow-listed
- [ ] Server-side session read in Server Components / route handlers
- [ ] Roles stored in DB; permission checks on every mutating action
- [ ] RLS policies mirror the app's authorization rules
- [ ] Sign-out, session refresh, and expired-session handling tested
- [ ] Error + loading states on all auth screens; accessible forms (labels, focus, errors announced)

## Common mistakes (avoid)
- Trusting a client-sent role or user id. Always derive identity server-side.
- Protecting the UI but not the API/action — the real gate is the server.
- Storing secrets (client secret, service keys) in client bundles or committing `.env`.
- Forgetting the production redirect URI, so OAuth works locally and breaks on deploy.

## How the best do it
Linear/Notion/Stripe: SSO + granular org roles, server-enforced, short-lived sessions, audit logs on
sensitive actions. Copy the *logic* (server-enforced RBAC, least privilege), not the UI.

## Prompt pack
When building auth, generate prompts for: middleware protection → provider setup → session helpers →
RBAC model + DB → RLS policies → tests (sign-in/out, expired, unauthorized). End each with a DoD line.
