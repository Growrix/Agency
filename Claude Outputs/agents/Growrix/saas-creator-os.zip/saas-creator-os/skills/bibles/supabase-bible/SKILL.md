---
name: supabase-bible
description: Supabase standard — Postgres, Row Level Security, auth integration, storage, realtime, and edge functions. Loads when wiring Supabase, RLS, storage, or realtime.
---

# Supabase Bible

## The standard
- Treat Supabase as managed Postgres first. Schema via Prisma migrations; keep migrations in the repo.
- **RLS is the security boundary.** Enable it on every user/tenant table and write policies that mirror
  app authorization. Never rely on client-side filtering for security.
- Use the service-role key **only** on the server; the anon key is for the client and must be safe under RLS.
- Storage buckets get their own access policies. Realtime only on tables where you need live updates.

## Checklist
- [ ] RLS enabled on all tenant-scoped tables; policies tested (owner can, others cannot)
- [ ] Service-role key server-only; anon key safe because RLS is correct
- [ ] Storage bucket policies set; signed URLs for private files
- [ ] Realtime subscriptions scoped and cleaned up; no leaks
- [ ] Migrations in repo; environments (local/staging/prod) reproducible
- [ ] Backups / point-in-time recovery configured

## Common mistakes (avoid)
- Shipping the service-role key to the client. RLS off "temporarily" → tenant data leak.
- Filtering sensitive data only in the client query. Unbounded realtime subscriptions.

## How the best do it
RLS-first, least-privilege keys, signed URLs for private assets, migrations in CI. Security lives in the DB.

## Prompt pack
Schema/migrations → enable + write RLS → storage policies → realtime (scoped) → key hygiene → RLS tests.
