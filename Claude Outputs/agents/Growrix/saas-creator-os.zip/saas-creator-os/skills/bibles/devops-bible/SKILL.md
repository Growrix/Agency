---
name: devops-bible
description: Deployment and operations standard — environments, secrets, CI/CD, monitoring, logging, backups, and rollback. Loads when setting up deploys, pipelines, or production readiness.
---

# DevOps Bible

## The standard
- Three environments: local, staging (mirrors prod), production. Config via environment variables; secrets
  in a secret manager, never in the repo.
- CI runs typecheck, lint, and tests on every push; a red pipeline blocks merge and deploy.
- Deploys are reproducible and reversible (a one-click/one-command rollback exists).
- Production has error monitoring, structured logging, uptime checks, and database backups.

## Checklist
- [ ] Env separation; secrets in a manager; `.env` git-ignored
- [ ] CI: typecheck + lint + tests green before merge
- [ ] Automated deploy (Vercel/Railway/Fly/Coolify) with rollback
- [ ] Error monitoring + structured logs + uptime/alerting
- [ ] DB backups + tested restore; migrations run safely in the pipeline
- [ ] Runbook for incidents and rollback

## Common mistakes (avoid)
- Secrets committed or pasted in client code. Deploying without a rollback path.
- No monitoring → you learn about outages from users. Backups never restore-tested.

## How the best do it
Everything through CI, immutable/reversible deploys, observability by default, backups verified by drills.

## Prompt pack
Env + secrets → CI pipeline → deploy + rollback → monitoring/logging → backups + restore test → runbook.
