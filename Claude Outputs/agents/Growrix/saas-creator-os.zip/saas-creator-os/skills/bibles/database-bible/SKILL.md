---
name: database-bible
description: Database standard — schema design, naming, relationships, indexes, enums, migrations, RLS, and backups (Prisma + Postgres). Loads when designing tables, writing schema, or adding migrations.
---

# Database Bible

## The standard (Prisma + Postgres/Supabase)
- Snake_case tables, singular model names, explicit foreign keys, `created_at`/`updated_at` on every table.
- Index every foreign key and every column you filter or sort on. Add composite indexes for common queries.
- Use enums for fixed sets. Keep money as integers (minor units) or `Decimal`, never floats.
- Every migration is reviewed and reversible. Never edit a shipped migration — add a new one.
- **RLS on by default** for multi-tenant data; policies mirror app authorization.

## Checklist
- [ ] Naming convention consistent; timestamps on every table
- [ ] FKs indexed; hot query columns indexed; no full-table scans on core paths
- [ ] Enums for fixed sets; correct numeric types (no float money)
- [ ] Migrations generated, reviewed, reversible; seed script for real reference data
- [ ] RLS policies present and tested for each tenant-scoped table
- [ ] N+1 queries avoided (use `include`/joins); pagination on list endpoints

## Common mistakes (avoid)
- Floats for money (rounding errors). Duplicate/So-called "unique" data without a unique constraint.
- Missing indexes → slow as data grows. Editing an applied migration → drift between environments.
- RLS off "for now" → data leaks between tenants.

## How the best do it
Supabase/Stripe: strict schemas, migrations in CI, RLS as the last line of defense, backups + point-in-time
recovery. Model the *discipline*: schema is code, reviewed and versioned.

## Prompt pack
Design schema → generate Prisma models → migration → RLS policies → seed real data → query-perf check.
