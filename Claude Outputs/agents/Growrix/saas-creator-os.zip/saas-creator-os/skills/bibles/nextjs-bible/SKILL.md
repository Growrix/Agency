---
name: nextjs-bible
description: Next.js App Router standard — Server vs Client Components, data fetching, routing, metadata/SEO, images/fonts, and performance. Loads when building pages, layouts, or optimizing Core Web Vitals.
---

# Next.js Bible

## The standard (App Router, React 19+)
- **Server Components by default.** Add `"use client"` only where you need state, effects, or browser APIs.
- Fetch data on the server (in Server Components / route handlers); pass minimal props to Client Components.
- Co-locate `loading.tsx`, `error.tsx`, and empty states. Every async surface has all three.
- Images via `next/image`, fonts via `next/font`. Dynamic-import heavy client-only widgets.
- Metadata via the `metadata` export / `generateMetadata`; add sitemap, robots, Open Graph, canonical.

## Checklist
- [ ] Client Components minimized; server data fetching preferred
- [ ] loading / error / empty states on every data view
- [ ] next/image + next/font; no layout shift (CLS); LCP element prioritized
- [ ] Route-level metadata, sitemap, robots, OG tags
- [ ] Code-split heavy client bundles; prefetch key routes
- [ ] Lighthouse: Perf 95+, A11y 100, SEO 100, Best Practices 100

## Common mistakes (avoid)
- Marking whole trees `"use client"` and shipping server logic to the browser.
- Fetching in the client what could be fetched on the server. Unoptimized images → poor LCP/CLS.
- Missing metadata → weak SEO. Blocking fonts → poor FCP.

## How the best do it
Vercel/Linear: mostly server-rendered, tiny client islands, aggressive asset optimization, metadata as code.

## Prompt pack
Layout + routing → server data layer → client islands → states → metadata/SEO → perf pass (Lighthouse).
