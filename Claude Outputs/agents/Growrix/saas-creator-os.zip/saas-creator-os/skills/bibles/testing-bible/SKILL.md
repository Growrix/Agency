---
name: testing-bible
description: Testing standard — what to unit-test, integration-test, and e2e-test; where tests live; and the definition of "tests pass". Loads when writing tests or defining a feature's test DoD.
---

# Testing Bible

## The standard
- **Pure logic (packages/core) is unit-tested exhaustively** — this is where correctness lives (e.g. money,
  P&L, permissions). Fast, no I/O, deterministic.
- Integration-test the seams (API routes, DB access, auth) with a test database.
- A small set of **e2e** tests covers the critical user journeys (sign in → do the core job → see result).
- Test error, loading, and empty states, not just the happy path.

## Checklist
- [ ] Core business logic has unit tests covering edge cases and failure modes
- [ ] Critical API/DB/auth paths have integration tests against a test DB
- [ ] 1–3 e2e tests cover the primary journeys
- [ ] Tests run in CI and block merge on failure
- [ ] "Tests pass" in a DoD means the exact command exits 0 locally and in CI

## Common mistakes (avoid)
- Testing implementation details instead of behavior. Only happy-path coverage.
- Slow, flaky e2e tests as the only safety net. No test DB → tests mutate real data.

## How the best do it
Thick unit coverage on pure logic, thin e2e on journeys, everything in CI. Confidence per minute is the metric.

## Prompt pack
Unit tests (core) → integration tests (seams) → e2e (journeys) → wire into CI → make "tests pass" concrete.
