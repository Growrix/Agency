---
name: architect
description: Produce the technical architecture (folders, data model, API, auth, integrations, automation, deployment) from an approved PRD. Use after /plan.
---

# /architect

Prerequisite: `state/prd.md` exists and is approved.

1. Invoke the **architect** subagent to write `state/architecture.md`.
2. Update `state/backlog.yaml` so features depend on `architecture_approved` (and `db_schema_approved`
   where relevant).
3. Set `phase: architect`. Tell the human to review, then start the first feature with `/blueprint <id>`.

Concrete over abstract. Real names and paths. No mock data.
