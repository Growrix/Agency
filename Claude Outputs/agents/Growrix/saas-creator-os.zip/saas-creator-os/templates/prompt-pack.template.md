# Prompt — <feature-id> · Step <NN>: <step name>

> Paste this into Cursor / Claude Code / Codex as one message. Do one step at a time, in order.

## Goal
<one sentence: what this step produces>

## Context (project reality — do not use placeholders)
- Stack: <from state/project.yaml>
- Files to create/edit: <exact paths>
- Conventions: follow the project CLAUDE.md and the relevant Bible (<topic>-bible).

## Instructions
1. <step>
2. <step>
3. <step>

## Constraints
- Real data only. Handle loading, error, and empty states.
- Keep types strict; keep components reusable and accessible (WCAG AA+).

## Done when:
<the exact DoD item this maps to — e.g. "npx tsc --noEmit passes and /sign-in protects /dashboard">
