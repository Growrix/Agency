# <PROJECT NAME> — runs on SaaS Creator OS

This project is governed by the SaaS Creator OS. The operating laws live in the plugin's kernel
(CLAUDE.md). Project-specific notes and overrides go below.

## Project overrides
- Stack overrides: (none — using OS defaults)
- Special constraints: (e.g. Shariah compliance, HIPAA, offline-first)
- Deadline: <YYYY-MM-DD>

## Where things live
- `state/project.yaml` — idea, type, phase, current feature, next task
- `state/prd.md` — product requirements
- `state/architecture.md` — technical architecture
- `state/backlog.yaml` — ordered features
- `state/features/*.yaml` — per-feature spec + DoD + approval
- `prompts/<feature>/` — copy-paste prompt packs for Cursor / Claude Code / Codex

Start or resume with `/status`, then `/next`.
